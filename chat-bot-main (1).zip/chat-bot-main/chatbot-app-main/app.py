from flask import Flask, request, jsonify, session
from flask_cors import CORS
import datetime

app = Flask(__name__)
app.secret_key = "chatbot_secret_key"

# Enhanced CORS config to allow specific routes and origins
CORS(app, resources={r"/chat": {"origins": "*"}})

def get_current_time():
    now = datetime.datetime.now()
    return now.strftime("%I:%M %p on %A, %B %d, %Y")

# Emoji description mapping
emoji_descriptions = {
    "😂": "It seems you're very happy or found something really funny!",
    "😊": "You look happy and pleased!",
    "😢": "I'm sorry you're feeling sad. Can I help with anything?",
    "😠": "I understand you're upset. Let me know what went wrong.",
    "👍": "Great! I'm glad you approve.",
    "❤️": "That's sweet! Sending love back. ❤️",
    "😎": "You're looking cool! 😎",
    "🤔": "Hmm... Are you thinking about something? Let me know how I can help."
}

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "").strip()
    user_message_lower = user_message.lower()
    session.permanent = True

    if user_message in emoji_descriptions:
        return jsonify({"reply": emoji_descriptions[user_message]})

    if "order_step" in session:
        if session["order_step"] == "awaiting_order_id":
            session.pop("order_step")
            return jsonify({
                "reply": f"📦 Your order with ID {user_message} is on the way! 🚚 Click here to track it: https://example.com/track/{user_message}"
            })

    if user_message_lower in ["hi", "hello", "hey"]:
        return jsonify({"reply": "Hello! Welcome to our support. 😊 How can I assist you today?"})

    elif any(x in user_message_lower for x in ["track my order", "where is my order", "i didn't get my order", "my order"]):
        session["order_step"] = "awaiting_order_id"
        return jsonify({"reply": "🔍 Please enter your Order ID so I can check the status for you."})

    elif "refund" in user_message_lower:
        return jsonify({"reply": "💰 To request a refund, please provide your order number. Refunds are processed within 5-7 business days."})

    elif "cancel" in user_message_lower:
        return jsonify({"reply": "❌ To cancel your order, go to 'My Orders' and select the order. Let me know if you need help doing that!"})

    elif "human" in user_message_lower:
        return jsonify({"reply": "👨‍💼 Connecting you to a human representative... Please hold on."})

    elif "time" in user_message_lower:
        return jsonify({"reply": f"🕒 Current server time is {get_current_time()}."})

    elif "payment" in user_message_lower or "methods" in user_message_lower:
        return jsonify({"reply": "💳 We accept credit/debit cards, net banking, UPI, and major wallets."})

    elif "location" in user_message_lower or "address" in user_message_lower:
        return jsonify({"reply": "📍 Our head office is located at 123 Support Lane, Help City, Supportland."})

    elif "thank you" in user_message_lower or "thanks" in user_message_lower:
        return jsonify({"reply": "🙏 You're welcome! Is there anything else I can help you with?"})

    return jsonify({"reply": "🤖 I'm sorry, I didn't understand that. Could you please rephrase or ask something else?"})

if __name__ == "__main__":
    # Use 0.0.0.0 to allow external access for frontend running on other devices or IPs
    app.run(debug=True, host="0.0.0.0", port=5000)
